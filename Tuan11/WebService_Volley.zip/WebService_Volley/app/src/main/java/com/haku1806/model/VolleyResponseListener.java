package com.haku1806.model;

public interface VolleyResponseListener {
    void onErro(String mesage);
    void onResponse(ModelCommom response);
}
