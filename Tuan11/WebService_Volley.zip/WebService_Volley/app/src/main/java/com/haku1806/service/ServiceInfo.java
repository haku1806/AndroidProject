package com.haku1806.service;

public class ServiceInfo {
    public static final String Base_URL="https://static.pipezero.com/covid/";
}
