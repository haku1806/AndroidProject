package com.haku1806.xulysukien;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity implements View.OnLongClickListener{

    TextView txtHienThiTuoi, txtHienThiMauSac, txtHienThiMonAn, txtHienThiTheThao;
    Button btnTinhTuoi, btnMauSac, btnMonAn, btnTheThao, btnAn, btnHien, btnDoiManHinh;
    EditText etxtNamSinh;

    View.OnClickListener eventVariable = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
    }

    private void addControls() {
        txtHienThiTuoi = findViewById(R.id.txtHienThiTuoi);
        btnTinhTuoi = findViewById(R.id.btnTinhTuoi);
        etxtNamSinh = findViewById(R.id.etxtNamSinh);

        txtHienThiMauSac = findViewById(R.id.txtHienThiMauSac);
        btnMauSac = findViewById(R.id.btnMauSac);

        txtHienThiMonAn = findViewById(R.id.txtHienThiMonAn);
        btnMonAn = findViewById(R.id.btnMonAn);

        txtHienThiTheThao = findViewById(R.id.txtHienThiTheThao);
        btnTheThao = findViewById(R.id.btnTheThao);

        btnAn = findViewById(R.id.btnAn);
        btnHien = findViewById(R.id.btnHien);
        btnDoiManHinh = findViewById(R.id.btnDoiManHinh);
    }

    public void eventTinhTuoi(View view) {
        int namHienTai = Calendar.getInstance().get(Calendar.YEAR);
        int namSinh = Integer.parseInt(etxtNamSinh.getText().toString());
        int tuoi = namHienTai - namSinh;
        txtHienThiTuoi.setText("Tuổi của bạn là: " + tuoi + " đã già rồi đó!");
        txtHienThiTuoi.setTextColor(Color.RED);
    }

    public void eventTheThao() {
        txtHienThiTheThao.setText("Thích chơi ngu!");
        txtHienThiTheThao.setTextColor(Color.CYAN);
    }

    public void eventMonAn() {
        txtHienThiMonAn.setText("Thích bún bò!");
        txtHienThiTheThao.setTextColor(Color.BLUE);
    }
    private void addEvents() {
        btnMauSac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtHienThiMauSac.setText("Yêu màu xanh...");
                txtHienThiMauSac.setTextColor(Color.GREEN);
            }
        });
        eventVariable = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.getId() == R.id.btnMonAn) {
                    eventMonAn();
                }
                else if (view.getId() == R.id.btnTheThao) {
                    eventTheThao();
                }
            }
        };
        btnMonAn.setOnClickListener(eventVariable);
        btnTheThao.setOnClickListener(eventVariable);
        btnAn.setOnLongClickListener(this);
        btnHien.setOnClickListener(new MyEvent());
    }

    @Override
    public boolean onLongClick(View view) {
        if (view.getId() == R.id.btnAn) {
            btnAn.setVisibility(View.INVISIBLE);
        }
        return false;
    }

    public void eventChuyenManHinh(View view) {
        Button btnMoi = new Button(MainActivity.this) {
            @Override
            public boolean performClick() {
                setContentView(R.layout.activity_main);
                addControls();
                addEvents();
                return super.performClick();
            }
        };
        btnMoi.setText("Quay về");
        btnMoi.setHeight(400);
        btnMoi.setWidth(200);
        btnMoi.setTextSize(24);
        // Hien thi button moi trong man hinh
        setContentView(btnMoi);
    }

    private class MyEvent implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.btnHien) {
                btnAn.setVisibility(View.VISIBLE);
            }
        }
    }
}