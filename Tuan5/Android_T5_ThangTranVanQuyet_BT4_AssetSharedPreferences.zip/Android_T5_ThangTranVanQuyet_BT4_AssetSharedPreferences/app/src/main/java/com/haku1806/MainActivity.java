package com.haku1806;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    TextView txtView;
    ListView lsvDsFont;
    ArrayList<String> ds_NameFont = new ArrayList<>();
    ArrayAdapter<String> adapterFont;
    String nameSave = "fontPosition";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
    }

    private void addEvents() {
        lsvDsFont.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // Set font
                Typeface typeface = Typeface.createFromAsset(getAssets(), "font/" + ds_NameFont.get(i));
                txtView.setTypeface(typeface);

                // Save font
                SharedPreferences sharedPreferences = getSharedPreferences(nameSave, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("fontName", "font/" + ds_NameFont.get(i));
                editor.commit();
            }
        });
    }

    private void addControls() {
        lsvDsFont = findViewById(R.id.lsv_dsFont);
        txtView = findViewById(R.id.txtView);
        // Case 1
//        ds_NameFont.add("FRABK.TTF");
//        ds_NameFont.add("georgia.ttf");
//        ds_NameFont.add("georgiab.ttf");
//        ds_NameFont.add("georgiai.ttf");
//        ds_NameFont.add("georgiaz.ttf");
//        ds_NameFont.add("SketchFlow Print.ttf");
//        ds_NameFont.add("SNAP____.TTF");
//        ds_NameFont.add("STENCIL.TTF");
//        ds_NameFont.add("sylfaen.ttf");
//        ds_NameFont.add("symbol.ttf");

        // Case 2
        try {
            AssetManager assetManager = getAssets();
            String ArrFontName[] = assetManager.list("font");
            ds_NameFont.addAll(Arrays.asList(ArrFontName));
            adapterFont = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, ds_NameFont);
            lsvDsFont.setAdapter(adapterFont);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Load font
        SharedPreferences sharedPreferences = getSharedPreferences(nameSave, MODE_PRIVATE);
        String _font = sharedPreferences.getString("fontName", "");
        if (_font.length() > 0) {
            Typeface typeface = Typeface.createFromAsset(getAssets(), _font);
            txtView.setTypeface(typeface);
        }
    }
}