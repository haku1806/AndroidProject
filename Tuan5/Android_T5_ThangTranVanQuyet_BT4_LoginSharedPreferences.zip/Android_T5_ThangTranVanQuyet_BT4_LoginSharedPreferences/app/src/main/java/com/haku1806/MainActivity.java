package com.haku1806;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etxtMail, etxtPassword;
    Button btnLogin;
    CheckBox ckbRememberMe;

    String saveinfo = "info";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        addEvents();
    }

    private void addEvents() {
        // Login
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Save info login
                SharedPreferences sharedPreferences = getSharedPreferences(saveinfo, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                // Save key-value
                editor.putString("email", etxtMail.getText().toString());
                editor.putString("password", etxtPassword.getText().toString());
                editor.putBoolean("save", ckbRememberMe.isChecked());
                editor.commit();
                Toast.makeText(MainActivity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addControls() {
        etxtMail = findViewById(R.id.etxtEmail);
        etxtPassword = findViewById(R.id.etxtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        ckbRememberMe = findViewById(R.id.ckbRememberMe);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Show info saved
        SharedPreferences sharedPreferences = getSharedPreferences(saveinfo, MODE_PRIVATE);
        String email = sharedPreferences.getString("email", "");
        String password = sharedPreferences.getString("password", "");
        boolean save = sharedPreferences.getBoolean("save", false);
        if (save) {
            etxtMail.setText(email);
            etxtPassword.setText(password);
            ckbRememberMe.setChecked(save);
        }
    }
}