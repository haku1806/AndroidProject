package com.haku1806;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnThem, btnSua, btnXoa;
    ListView lsvDanhBa;
    ArrayList<String> arrDanhBa;
    ArrayAdapter<String> adapterDanhBa;

    // Database
    String DB_NAME = "dbcontact.db";
    private String DB_PATH = "/databases/";
    SQLiteDatabase database = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        processCopyDatabase2Assets();
        addControls();
        addEvents();
        showAllContacts();
    }

    private void showAllContacts() {
        // Open database
        database = openOrCreateDatabase(DB_NAME, MODE_PRIVATE, null);
        // Raw query
        Cursor cursor = database.query("contact", null, null, null, null, null, null);
        // Clear data arrList
        arrDanhBa.clear();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            arrDanhBa.add(id + " - " + name + " - " + phone);
        }
        cursor.close();
        adapterDanhBa.notifyDataSetChanged();
    }

    private void addEvents() {
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processBtnXoa();
            }
        });

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processThem();
            }
        });

        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processSua();
            }
        });
    }

    private void processSua() {
        ContentValues row = new ContentValues();
        row.put("name", "Khánh Lam");

        database.update("contact", row, "id=?", new String[]{"2"});
        showAllContacts();
    }

    private void processThem() {
        ContentValues row = new ContentValues();
        row.put("id", "5");
        row.put("name", "Thanh Hoa");
        row.put("phone", "0855622141");

        // r : total line process
        long r = database.insert("contact", null, row);
        Toast.makeText(this, "Vừa thêm 1 dòng dữ liệu r = " + r, Toast.LENGTH_SHORT).show();
        showAllContacts();
    }

    private void processBtnXoa() {
        database.delete("contact", "id=?", new String[] {"5"});
        showAllContacts();
    }

    private void processCopyDatabase2Assets() {
        File dbFile = getDatabasePath(DB_NAME);
        // Check if exists
        if (!dbFile.exists()) {
            copyDatabase();
            Toast.makeText(this, "Dữ liệu được sao chép thành công", Toast.LENGTH_SHORT).show();
        } else {
            dbFile.delete();
            copyDatabase();
        }
    }

    private void copyDatabase() {
        try {
            InputStream myInput = getAssets().open(DB_NAME);
            String outFileName = getApplicationInfo().dataDir + DB_PATH + DB_NAME;
            File f = new File(getApplicationInfo().dataDir + DB_PATH);
            if (!f.exists()) {
                f.mkdir();
            }

            OutputStream myOutPut = new FileOutputStream(outFileName);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = myInput.read(buffer)) > 0) {
                myOutPut.write(buffer, 0, len);
            }

            myOutPut.flush();
            myInput.close();
            myOutPut.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            Log.e("Lỗi sao chép:", ex.toString());
        }
    }

    private void addControls() {
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnXoa = findViewById(R.id.btnXoa);
        lsvDanhBa = findViewById(R.id.lsvDanhBa);

        arrDanhBa = new ArrayList<>();
        adapterDanhBa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrDanhBa);
        lsvDanhBa.setAdapter(adapterDanhBa);
    }
}