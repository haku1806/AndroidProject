package com.haku1806.bt24.spinnerapp.adapter;

import android.app.Activity;
import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.haku1806.bt24.spinnerapp.Model.Ban;
import com.haku1806.bt24.spinnerapp.R;

import java.util.List;

public class BanAnAdapter extends ArrayAdapter<Ban> {
    Activity context;
    int resource;
    @NonNull List<Ban> objects;

    public BanAnAdapter(@NonNull Activity context, int resource, @NonNull List<Ban> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View row, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = this.context.getLayoutInflater();
        row = layoutInflater.inflate(this.resource, null);

        TextView _soban = row.findViewById(R.id.txtSoBan);
        ImageView _img = row.findViewById(R.id.imageView);

        Ban ban = this.objects.get(position);
        _soban.setText(ban.get_soBan());
        _img.setImageResource(ban.get_linkAnh());

        return row;
    }
}
