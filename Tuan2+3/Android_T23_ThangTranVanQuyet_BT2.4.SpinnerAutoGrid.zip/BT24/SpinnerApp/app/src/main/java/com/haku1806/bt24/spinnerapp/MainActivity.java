package com.haku1806.bt24.spinnerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.haku1806.bt24.spinnerapp.Model.NhanVien;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button btnNext;
    private EditText edtTenNhanVien, edtSoNgayCongTac;
    private Spinner spinSoNgayCongTac;
    private TextView tvResult;
    private int point;

    List<String> listThu;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initWidgets();
        buildEvents();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AutoComplete.class);
                startActivity(intent);
            }
        });
    }

    private void buildEvents() {
        listThu = new ArrayList<>();
        String[] arrThu = getResources().getStringArray(R.array.arrThu);

        for (String item : arrThu) {
            listThu.add(item);
        }

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, listThu);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinSoNgayCongTac.setAdapter(adapter);

        spinSoNgayCongTac.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                point = i;
                Toast.makeText(MainActivity.this, listThu.get(i), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void initWidgets() {
        edtTenNhanVien = findViewById(R.id.id_edt_nhan_vien);
        edtSoNgayCongTac = findViewById(R.id.id_edt_so_ngay_cong_tac);
        spinSoNgayCongTac = findViewById(R.id.id_spin_thu);
        tvResult = findViewById(R.id.id_tv_result);

        btnNext = findViewById(R.id.btnNext);
    }


    public void confirmSubmit(View view) {
        if (view.getId() == R.id.id_btn_submit) {
            String tenNhanVien = String.valueOf(edtTenNhanVien.getText()).trim(),
                    soNgayCongTac = String.valueOf(edtSoNgayCongTac.getText()).trim();

            if (TextUtils.isEmpty(tenNhanVien) || TextUtils.isEmpty(soNgayCongTac)) {
                Toast.makeText(this, "Thiếu dữ liệu!", Toast.LENGTH_SHORT).show();
            } else {
                NhanVien nhanVien = new NhanVien();
                nhanVien.setmTenNhanVien(tenNhanVien);
                nhanVien.setmNgayBatDau(listThu.get(point));
                nhanVien.setmSoNgayCongTac(Integer.valueOf(soNgayCongTac));
                tvResult.setText(nhanVien.toString());

//                Toast.makeText(this, nhanVien.toString(), Toast.LENGTH_LONG).show();
            }
        }
    }
}