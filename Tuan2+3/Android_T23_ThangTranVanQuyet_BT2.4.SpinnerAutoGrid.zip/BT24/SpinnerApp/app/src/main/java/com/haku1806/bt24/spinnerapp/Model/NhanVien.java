package com.haku1806.bt24.spinnerapp.Model;

public class NhanVien {
    private String mTenNhanVien, mNgayBatDau;
    private int mSoNgayCongTac;

    public NhanVien(String mTenNhanVien, String mNgayBatDau, int mSoNgayCongTac) {
        this.mTenNhanVien = mTenNhanVien;
        this.mNgayBatDau = mNgayBatDau;
        this.mSoNgayCongTac = mSoNgayCongTac;
    }

    public NhanVien() {

    }

    public String getmTenNhanVien() {
        return mTenNhanVien;
    }

    public void setmTenNhanVien(String mTenNhanVien) {
        this.mTenNhanVien = mTenNhanVien;
    }

    public String getmNgayBatDau() {
        return mNgayBatDau;
    }

    public void setmNgayBatDau(String mNgayBatDau) {
        this.mNgayBatDau = mNgayBatDau;
    }

    public int getmSoNgayCongTac() {
        return mSoNgayCongTac;
    }

    public void setmSoNgayCongTac(int mSoNgayCongTac) {
        this.mSoNgayCongTac = mSoNgayCongTac;
    }

    @Override
    public String toString() {
        String result = "Nhân viên " + this.mTenNhanVien +
                "\nBắt đầu đi công tác vào " + this.mNgayBatDau +
                "\nDự kiến số ngày là " + this.mSoNgayCongTac + " ngày";
        return result;
    }
}
