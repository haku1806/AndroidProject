package com.haku1806.bt24.spinnerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.haku1806.bt24.spinnerapp.Model.Ban;
import com.haku1806.bt24.spinnerapp.adapter.BanAnAdapter;

import java.util.ArrayList;

public class GridView extends AppCompatActivity {

    GridView _gridview;
    BanAnAdapter banAnAdapter;
    ArrayList<Ban> dsBan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view);

        initEvents();
        initControls();
    }

    private void initControls() {
//        _gridview = findViewById(R.id.grid_View);
//        dsBan.add(new Ban("Bàn số: 01", R.drawable.table_512px));
//        dsBan.add(new Ban("Bàn số: 02", R.drawable.table_512px));
//        dsBan.add(new Ban("Bàn số: 03", R.drawable.table_512px));
//        dsBan.add(new Ban("Bàn số: 04", R.drawable.table_512px));
//        dsBan.add(new Ban("Bàn số: 05", R.drawable.table_512px));
//        dsBan.add(new Ban("Bàn số: 06", R.drawable.table_512px));
//
//        banAnAdapter = new BanAnAdapter(
//                GridView.this, R.layout.item_ban, dsBan
//        );
//        _gridview.setAdapter(banAnAdapter);
    }

    private void initEvents() {
    }
}