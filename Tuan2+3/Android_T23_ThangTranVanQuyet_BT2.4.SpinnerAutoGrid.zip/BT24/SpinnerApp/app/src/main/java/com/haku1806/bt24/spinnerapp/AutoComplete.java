package com.haku1806.bt24.spinnerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

public class AutoComplete extends AppCompatActivity {

    EditText etxtTen;
    Button btnSubmit, btnNext;
    TextView txtResult;

    AutoCompleteTextView autoNoiSinh;
    String[] arrTinh;
    ArrayAdapter<String> adapterTinh;

    MultiAutoCompleteTextView multiAutoMonHoc;
    String[] arrMonHoc;
    ArrayAdapter<String> adapterMonHoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_complete);

        initControls();
        initEvents();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AutoComplete.this, GridView.class);
                startActivity(intent);
            }
        });
    }

    private void initControls() {
        etxtTen = findViewById(R.id.etxtTen);
        txtResult = findViewById(R.id.txtResult);
        btnSubmit = findViewById(R.id.btnSubmit);

        autoNoiSinh = findViewById(R.id.autoNoiSinh);
        arrTinh = getResources().getStringArray(R.array.arrTinh);
        adapterTinh = new ArrayAdapter<String>(AutoComplete.this, android.R.layout.simple_list_item_1, arrTinh);
        autoNoiSinh.setAdapter(adapterTinh);

        multiAutoMonHoc = findViewById(R.id.multiAutoMonHoc);
        arrMonHoc = getResources().getStringArray(R.array.arrMonHoc);
        adapterMonHoc = new ArrayAdapter<String>(AutoComplete.this, android.R.layout.simple_list_item_1, arrMonHoc);
        multiAutoMonHoc.setAdapter(adapterMonHoc);
        multiAutoMonHoc.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        btnNext = findViewById(R.id.btnNext);
    }

    private void initEvents() {
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                processSubmit();
            }
        });
    }

    private void processSubmit() {
        txtResult.setText("Bạn tên là: " + etxtTen.getText().toString() +
                "\nSinh ở: " + autoNoiSinh.getText().toString() +
                "\nĐã chọn môn: " + multiAutoMonHoc.getText().toString());

    }


}