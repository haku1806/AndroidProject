package com.haku1806.bt23.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.haku1806.bt23.R;
import com.haku1806.bt23.model.DanhBa;

import java.util.List;

public class DanhBaAdapter extends ArrayAdapter<DanhBa> {
    Activity context;
    int resource;
    List<DanhBa> objects;

    public DanhBaAdapter(@NonNull Activity context, int resource, @NonNull List<DanhBa> objects) {
        super(context, resource, objects);
        this.context = context;
        this.objects = objects;
        this.resource = resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View row, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = this.context.getLayoutInflater();
        row = layoutInflater.inflate(this.resource, null);
        TextView _name = row.findViewById(R.id.txtName);
        TextView _Phnne = row.findViewById(R.id.txt_numberPhone);
        DanhBa danhBa = this.objects.get(position);
        _name.setText(danhBa.getName());
        _Phnne.setText(danhBa.getNumberPhone());

        return row;
    }
}
