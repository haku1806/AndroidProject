package com.haku1806.bt23;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.widget.ListView;

import com.haku1806.bt23.adapter.DanhBaAdapter;
import com.haku1806.bt23.model.DanhBa;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewDanhBa;
    ArrayList<DanhBa> dsDanhBa;
    DanhBaAdapter danhBaAdapter;

    public void addControls() {
        listViewDanhBa = findViewById(R.id.listviewDanhBa);

        dsDanhBa = new ArrayList<>();
        dsDanhBa.add(new DanhBa(1, "Thang Vip Pro", "0123456789"));
        dsDanhBa.add(new DanhBa(2, "Haku 1234", "0987654321"));
        dsDanhBa.add(new DanhBa(3, "Fung L", "784621102"));
        danhBaAdapter = new DanhBaAdapter(
                MainActivity.this, R.layout.view_danhba, dsDanhBa
        );
        listViewDanhBa.setAdapter(danhBaAdapter);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Danh bạ");
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        return super.onCreateOptionsMenu(menu);
    }
}